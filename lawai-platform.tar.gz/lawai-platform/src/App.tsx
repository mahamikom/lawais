import { Route, Switch } from 'wouter';
import Sidebar from './components/Sidebar';
import Home from './pages/Home';
import Contracts from './pages/Contracts';
import Consultations from './pages/Consultations';
import Complaints from './pages/Complaints';
import Search from './pages/Search';
import Account from './pages/Account';
import Pricing from './pages/Pricing';
import Library from './pages/Library';
import Invoices from './pages/Invoices';
import Assistants from './pages/Assistants';
import About from './pages/About';
import Contact from './pages/Contact';

function App() {
  return (
    <div className="flex min-h-screen bg-dark-bg">
      <Sidebar />
      <main className="flex-1 mr-64">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/contracts" component={Contracts} />
          <Route path="/consultations" component={Consultations} />
          <Route path="/complaints" component={Complaints} />
          <Route path="/search" component={Search} />
          <Route path="/account" component={Account} />
          <Route path="/pricing" component={Pricing} />
          <Route path="/library" component={Library} />
          <Route path="/invoices" component={Invoices} />
          <Route path="/assistants" component={Assistants} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
        </Switch>
      </main>
    </div>
  );
}

export default App;
