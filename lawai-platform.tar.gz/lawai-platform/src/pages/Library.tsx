import { FolderOpen, Plus } from 'lucide-react';

const Library = () => {
  return (
    <div className="p-8" dir="rtl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 text-right">مكتبة المستندات</h1>
        <p className="text-gray-400 text-right">نظّم وأدر مستنداتك القانونية</p>
      </div>

      <div className="flex justify-end mb-6">
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors font-bold flex items-center gap-2">
          <Plus className="w-5 h-5" />
          <span>إنشاء مجلد جديد</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="bg-dark-card border border-dark-border rounded-lg p-6 hover:border-blue-500 transition-all cursor-pointer"
          >
            <FolderOpen className="w-12 h-12 text-blue-400 mb-3" />
            <h3 className="text-lg font-bold mb-1 text-right">مجلد {i}</h3>
            <p className="text-sm text-gray-400 text-right">0 مستندات</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Library;
