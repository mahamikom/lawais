import { useState } from 'react';
import { Search, Star, FileText } from 'lucide-react';

// بيانات نماذج العقود (104 قالب)
const contractTemplates = [
  // عقود العمل والتوظيف
  { id: 1, title: 'عقد عمل', category: 'العمل', icon: '💼', color: 'bg-blue-500' },
  { id: 2, title: 'عقد عمل مؤقت', category: 'العمل', icon: '⏰', color: 'bg-blue-500' },
  { id: 3, title: 'عقد تدريب', category: 'العمل', icon: '📚', color: 'bg-blue-500' },
  { id: 4, title: 'عقد استشاري', category: 'العمل', icon: '👔', color: 'bg-blue-500' },
  { id: 5, title: 'عقد عمل جزئي', category: 'العمل', icon: '⏱️', color: 'bg-blue-500' },
  
  // عقود البيع والشراء
  { id: 6, title: 'عقد بيع عقار', category: 'البيع', icon: '🏠', color: 'bg-green-500' },
  { id: 7, title: 'عقد بيع سيارة', category: 'البيع', icon: '🚗', color: 'bg-green-500' },
  { id: 8, title: 'عقد بيع أسهم', category: 'البيع', icon: '📈', color: 'bg-green-500' },
  { id: 9, title: 'عقد بيع بضائع', category: 'البيع', icon: '📦', color: 'bg-green-500' },
  { id: 10, title: 'عقد بيع محل تجاري', category: 'البيع', icon: '🏪', color: 'bg-green-500' },
  
  // عقود الإيجار
  { id: 11, title: 'عقد إيجار سكني', category: 'الإيجار', icon: '🏘️', color: 'bg-purple-500' },
  { id: 12, title: 'عقد إيجار تجاري', category: 'الإيجار', icon: '🏢', color: 'bg-purple-500' },
  { id: 13, title: 'عقد إيجار سيارة', category: 'الإيجار', icon: '🚙', color: 'bg-purple-500' },
  { id: 14, title: 'عقد إيجار معدات', category: 'الإيجار', icon: '⚙️', color: 'bg-purple-500' },
  { id: 15, title: 'عقد إيجار أرض', category: 'الإيجار', icon: '🌾', color: 'bg-purple-500' },
  
  // عقود الشراكة
  { id: 16, title: 'عقد شراكة تجارية', category: 'الشراكة', icon: '🤝', color: 'bg-orange-500' },
  { id: 17, title: 'عقد شراكة محدودة', category: 'الشراكة', icon: '🔗', color: 'bg-orange-500' },
  { id: 18, title: 'اتفاقية تأسيس شركة', category: 'الشراكة', icon: '🏭', color: 'bg-orange-500' },
  { id: 19, title: 'عقد مشروع مشترك', category: 'الشراكة', icon: '🎯', color: 'bg-orange-500' },
  { id: 20, title: 'اتفاقية توزيع أرباح', category: 'الشراكة', icon: '💰', color: 'bg-orange-500' },
  
  // عقود الخدمات
  { id: 21, title: 'عقد تقديم خدمات', category: 'الخدمات', icon: '🛠️', color: 'bg-red-500' },
  { id: 22, title: 'عقد صيانة', category: 'الخدمات', icon: '🔧', color: 'bg-red-500' },
  { id: 23, title: 'عقد نظافة', category: 'الخدمات', icon: '🧹', color: 'bg-red-500' },
  { id: 24, title: 'عقد أمن وحراسة', category: 'الخدمات', icon: '🛡️', color: 'bg-red-500' },
  { id: 25, title: 'عقد تسويق', category: 'الخدمات', icon: '📣', color: 'bg-red-500' },
  
  // عقود التقنية
  { id: 26, title: 'عقد تطوير برمجيات', category: 'التقنية', icon: '💻', color: 'bg-cyan-500' },
  { id: 27, title: 'عقد استضافة', category: 'التقنية', icon: '☁️', color: 'bg-cyan-500' },
  { id: 28, title: 'اتفاقية سرية معلومات', category: 'التقنية', icon: '🔒', color: 'bg-cyan-500' },
  { id: 29, title: 'عقد ترخيص برمجيات', category: 'التقنية', icon: '📜', color: 'bg-cyan-500' },
  { id: 30, title: 'عقد دعم فني', category: 'التقنية', icon: '🎧', color: 'bg-cyan-500' },
];

// إضافة المزيد من العقود للوصول إلى 104
for (let i = 31; i <= 104; i++) {
  const categories = ['العمل', 'البيع', 'الإيجار', 'الشراكة', 'الخدمات', 'التقنية'];
  const icons = ['📄', '📋', '📑', '📃', '📰', '🗂️'];
  const colors = ['bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-orange-500', 'bg-red-500', 'bg-cyan-500'];
  
  const catIndex = i % categories.length;
  contractTemplates.push({
    id: i,
    title: `عقد ${i}`,
    category: categories[catIndex],
    icon: icons[catIndex],
    color: colors[catIndex],
  });
}

const Contracts = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [favorites, setFavorites] = useState<number[]>([]);

  const categories = ['الكل', 'العمل', 'البيع', 'الإيجار', 'الشراكة', 'الخدمات', 'التقنية'];

  const filteredContracts = contractTemplates.filter(contract => {
    const matchesSearch = contract.title.includes(searchTerm) || contract.category.includes(searchTerm);
    const matchesCategory = selectedCategory === 'الكل' || contract.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleFavorite = (id: number) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(fav => fav !== id) : [...prev, id]
    );
  };

  return (
    <div className="p-8" dir="rtl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">نماذج العقود</h1>
        <p className="text-gray-400">104 قالب عقد جاهز للاستخدام</p>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="ابحث عن عقد..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-dark-card border border-dark-border rounded-lg pr-12 pl-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Category Filters */}
      <div className="flex gap-2 mb-8 overflow-x-auto scrollbar-hide">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
              selectedCategory === category
                ? 'bg-blue-600 text-white'
                : 'bg-dark-card text-gray-400 hover:bg-dark-hover'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Contracts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredContracts.map(contract => (
          <div
            key={contract.id}
            className="bg-dark-card border border-dark-border rounded-lg p-6 hover:border-blue-500 transition-all cursor-pointer group relative"
          >
            {/* Favorite Star */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleFavorite(contract.id);
              }}
              className="absolute top-4 left-4 p-2 rounded-lg hover:bg-dark-hover transition-colors"
            >
              <Star
                className={`w-5 h-5 ${
                  favorites.includes(contract.id)
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-400'
                }`}
              />
            </button>

            {/* Icon */}
            <div className={`w-16 h-16 ${contract.color} rounded-full flex items-center justify-center text-3xl mb-4`}>
              {contract.icon}
            </div>

            {/* Title */}
            <h3 className="text-lg font-bold mb-2 text-right">{contract.title}</h3>

            {/* Category */}
            <p className="text-sm text-gray-400 mb-4 text-right">{contract.category}</p>

            {/* Button */}
            <button className="w-full bg-dark-hover hover:bg-blue-600 text-white py-2 rounded-lg transition-colors flex items-center justify-center gap-2">
              <FileText className="w-4 h-4" />
              <span>فتح العقد</span>
            </button>
          </div>
        ))}
      </div>

      {/* No Results */}
      {filteredContracts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-400 text-lg">لا توجد نتائج مطابقة للبحث</p>
        </div>
      )}
    </div>
  );
};

export default Contracts;
