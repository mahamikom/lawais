import { Target, TrendingUp, Eye } from 'lucide-react';

const About = () => {
  return (
    <div className="p-8 max-w-5xl mx-auto" dir="rtl">
      <div className="mb-12 text-center">
        <h1 className="text-5xl font-bold mb-4">عن المنصة</h1>
        <p className="text-xl text-gray-400">
          منصة قانونية ذكية مدعومة بالذكاء الاصطناعي
        </p>
      </div>

      {/* الهدف */}
      <div className="bg-dark-card border border-dark-border rounded-lg p-8 mb-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
            <Target className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 text-right">
            <h2 className="text-3xl font-bold mb-4">الهدف</h2>
            <p className="text-gray-300 leading-relaxed text-lg">
              تسهيل الوصول إلى الخدمات القانونية من خلال تقديم حلول ذكية مدعومة بالذكاء الاصطناعي. 
              نهدف إلى جعل الخدمات القانونية أكثر كفاءة وسرعة ودقة، مع توفير تجربة مستخدم استثنائية 
              تمكّن الأفراد والشركات من الحصول على المساعدة القانونية التي يحتاجونها بسهولة ويسر.
            </p>
          </div>
        </div>
      </div>

      {/* الطموح */}
      <div className="bg-dark-card border border-dark-border rounded-lg p-8 mb-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 text-right">
            <h2 className="text-3xl font-bold mb-4">الطموح</h2>
            <p className="text-gray-300 leading-relaxed text-lg">
              نطمح إلى أن نكون المنصة القانونية الرائدة في المملكة العربية السعودية والمنطقة، 
              من خلال تقديم خدمات قانونية متكاملة تجمع بين الخبرة البشرية والذكاء الاصطناعي. 
              نسعى لإحداث نقلة نوعية في طريقة تقديم الخدمات القانونية، وجعلها متاحة للجميع 
              بأسعار معقولة وجودة عالية.
            </p>
          </div>
        </div>
      </div>

      {/* الرؤية */}
      <div className="bg-dark-card border border-dark-border rounded-lg p-8">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
            <Eye className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 text-right">
            <h2 className="text-3xl font-bold mb-4">الرؤية</h2>
            <p className="text-gray-300 leading-relaxed text-lg">
              رؤيتنا هي بناء مستقبل قانوني رقمي حيث يمكن لأي شخص الوصول إلى الخدمات القانونية 
              بسهولة وسرعة. نؤمن بأن التكنولوجيا والذكاء الاصطناعي يمكن أن يحدثا ثورة في المجال 
              القانوني، ونعمل على تحقيق هذه الرؤية من خلال تطوير حلول مبتكرة تلبي احتياجات 
              عملائنا وتتجاوز توقعاتهم.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
