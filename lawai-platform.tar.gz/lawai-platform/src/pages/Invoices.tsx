import { FileText, Download } from 'lucide-react';

const Invoices = () => {
  const invoices = [
    { id: 1, date: '2024-01-15', amount: '49.00', status: 'مدفوعة', plan: 'شركة كبرى' },
    { id: 2, date: '2023-12-15', amount: '49.00', status: 'مدفوعة', plan: 'شركة كبرى' },
    { id: 3, date: '2023-11-15', amount: '49.00', status: 'مدفوعة', plan: 'شركة كبرى' },
  ];

  return (
    <div className="p-8 max-w-6xl mx-auto" dir="rtl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 text-right">الفواتير</h1>
        <p className="text-gray-400 text-right">عرض وتحميل فواتيرك</p>
      </div>

      <div className="bg-dark-card border border-dark-border rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-dark-bg">
            <tr>
              <th className="px-6 py-4 text-right text-sm font-bold">التاريخ</th>
              <th className="px-6 py-4 text-right text-sm font-bold">الخطة</th>
              <th className="px-6 py-4 text-right text-sm font-bold">المبلغ</th>
              <th className="px-6 py-4 text-right text-sm font-bold">الحالة</th>
              <th className="px-6 py-4 text-right text-sm font-bold">الإجراءات</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr key={invoice.id} className="border-t border-dark-border">
                <td className="px-6 py-4 text-right">{invoice.date}</td>
                <td className="px-6 py-4 text-right">{invoice.plan}</td>
                <td className="px-6 py-4 text-right">${invoice.amount}</td>
                <td className="px-6 py-4 text-right">
                  <span className="bg-green-900/30 text-green-400 px-3 py-1 rounded-full text-sm">
                    {invoice.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="text-blue-400 hover:text-blue-300 flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    <span>تحميل</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Invoices;
