const Home = () => {
  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">منصة الذكاء الاصطناعي القانونية</h1>
          <p className="text-xl text-gray-400">
            حلول قانونية ذكية مدعومة بالذكاء الاصطناعي
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-dark-card p-6 rounded-lg border border-dark-border hover:border-blue-500 transition-colors">
            <h3 className="text-xl font-bold mb-2">نماذج العقود</h3>
            <p className="text-gray-400">
              104 قالب عقد جاهز مع مراجعة ذكية بالذكاء الاصطناعي
            </p>
          </div>

          <div className="bg-dark-card p-6 rounded-lg border border-dark-border hover:border-blue-500 transition-colors">
            <h3 className="text-xl font-bold mb-2">الاستشارات القانونية</h3>
            <p className="text-gray-400">
              احصل على استشارات قانونية فورية من AI متخصص
            </p>
          </div>

          <div className="bg-dark-card p-6 rounded-lg border border-dark-border hover:border-blue-500 transition-colors">
            <h3 className="text-xl font-bold mb-2">نظام الشكاوى الذكي</h3>
            <p className="text-gray-400">
              توجيه تلقائي للشكاوى إلى الجهة الحكومية المختصة
            </p>
          </div>

          <div className="bg-dark-card p-6 rounded-lg border border-dark-border hover:border-blue-500 transition-colors">
            <h3 className="text-xl font-bold mb-2">البحث القانوني</h3>
            <p className="text-gray-400">
              محرك بحث ذكي في الأنظمة والتشريعات واللوائح
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
