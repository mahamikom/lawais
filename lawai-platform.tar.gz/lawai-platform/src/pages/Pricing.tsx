import { useState } from 'react';
import { Check, Zap } from 'lucide-react';

type BillingPeriod = 'monthly' | 'yearly' | 'lifetime';

const Pricing = () => {
  const [billingPeriod, setBillingPeriod] = useState<BillingPeriod>('monthly');

  const plans = {
    monthly: [
      {
        name: 'محترف',
        price: '19.00',
        credits: '250',
        description: 'لبدء رحلتك مع خدماتنا',
        features: [
          '250 اعتماد شهرياً',
          'الوصول لجميع نماذج العقود',
          'استشارات قانونية غير محدودة',
          'نظام الشكاوى الذكي',
          'محرك البحث القانوني',
          'الدعم الفني',
        ],
      },
      {
        name: 'شركة كبرى',
        price: '49.00',
        credits: '500',
        description: 'إنشاء مستندات قانونية بحد رقم 500 في الشهر',
        features: [
          '500 اعتماد شهرياً',
          'جميع مميزات الخطة المحترف',
          'أولوية في الدعم الفني',
          'تقارير مخصصة',
          'API Access',
          'مساعدون متعددون',
        ],
        popular: true,
      },
      {
        name: 'غير محدود',
        price: '79.00',
        credits: 'غير محدود',
        description: 'إنشاء مستندات قانونية غير محدودة',
        features: [
          'اعتمادات غير محدودة',
          'جميع مميزات الخطة الكبرى',
          'دعم فني مخصص 24/7',
          'تدريب مخصص',
          'استشارات استراتيجية',
          'SLA مضمون',
        ],
      },
    ],
    yearly: [
      {
        name: 'محترف',
        price: '190.00',
        credits: '250',
        description: 'وفر 16% مع الاشتراك السنوي',
        features: [
          '250 اعتماد شهرياً',
          'الوصول لجميع نماذج العقود',
          'استشارات قانونية غير محدودة',
          'نظام الشكاوى الذكي',
          'محرك البحث القانوني',
          'الدعم الفني',
        ],
      },
      {
        name: 'شركة كبرى',
        price: '490.00',
        credits: '500',
        description: 'وفر 16% مع الاشتراك السنوي',
        features: [
          '500 اعتماد شهرياً',
          'جميع مميزات الخطة المحترف',
          'أولوية في الدعم الفني',
          'تقارير مخصصة',
          'API Access',
          'مساعدون متعددون',
        ],
        popular: true,
      },
      {
        name: 'غير محدود',
        price: '790.00',
        credits: 'غير محدود',
        description: 'وفر 16% مع الاشتراك السنوي',
        features: [
          'اعتمادات غير محدودة',
          'جميع مميزات الخطة الكبرى',
          'دعم فني مخصص 24/7',
          'تدريب مخصص',
          'استشارات استراتيجية',
          'SLA مضمون',
        ],
      },
    ],
    lifetime: [
      {
        name: 'مدى الحياة',
        price: '999.00',
        credits: 'غير محدود',
        description: 'دفعة واحدة - وصول مدى الحياة',
        features: [
          'اعتمادات غير محدودة مدى الحياة',
          'جميع المميزات المتاحة',
          'تحديثات مجانية مدى الحياة',
          'دعم فني مخصص',
          'أولوية في الميزات الجديدة',
          'ضمان استرداد 30 يوم',
        ],
        popular: true,
      },
    ],
  };

  const currentPlans = plans[billingPeriod];

  return (
    <div className="p-8 max-w-7xl mx-auto" dir="rtl">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold mb-2">الخطط والأسعار</h1>
        <p className="text-gray-400">اختر الخطة المناسبة لاحتياجاتك</p>
      </div>

      {/* Billing Period Toggle */}
      <div className="flex justify-center mb-12">
        <div className="bg-dark-card border border-dark-border rounded-lg p-1 inline-flex">
          <button
            onClick={() => setBillingPeriod('monthly')}
            className={`px-6 py-2 rounded-lg transition-colors ${
              billingPeriod === 'monthly'
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            شهري
          </button>
          <button
            onClick={() => setBillingPeriod('yearly')}
            className={`px-6 py-2 rounded-lg transition-colors ${
              billingPeriod === 'yearly'
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            سنوي
          </button>
          <button
            onClick={() => setBillingPeriod('lifetime')}
            className={`px-6 py-2 rounded-lg transition-colors ${
              billingPeriod === 'lifetime'
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            مدى الحياة
          </button>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className={`grid gap-6 ${currentPlans.length === 3 ? 'md:grid-cols-3' : 'md:grid-cols-1 max-w-md mx-auto'}`}>
        {currentPlans.map((plan, index) => (
          <div
            key={index}
            className={`bg-dark-card border rounded-lg p-8 relative ${
              plan.popular
                ? 'border-blue-500 shadow-lg shadow-blue-500/20'
                : 'border-dark-border'
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-4 right-1/2 transform translate-x-1/2">
                <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-bold flex items-center gap-1">
                  <Zap className="w-4 h-4" />
                  الأكثر شعبية
                </span>
              </div>
            )}

            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <p className="text-gray-400 text-sm mb-4">{plan.description}</p>
              <div className="flex items-baseline justify-center gap-2">
                <span className="text-5xl font-bold">{plan.price}</span>
                <span className="text-gray-400">دولار أمريكي</span>
              </div>
              {billingPeriod !== 'lifetime' && (
                <p className="text-gray-400 text-sm mt-2">
                  {billingPeriod === 'monthly' ? 'شهرياً' : 'سنوياً'}
                </p>
              )}
            </div>

            <div className="mb-6 text-center">
              <div className="bg-dark-bg rounded-lg p-4">
                <p className="text-2xl font-bold">{plan.credits}</p>
                <p className="text-gray-400 text-sm">الاعتمادات {billingPeriod !== 'lifetime' && 'شهرياً'}</p>
              </div>
            </div>

            <ul className="space-y-3 mb-8">
              {plan.features.map((feature, featureIndex) => (
                <li key={featureIndex} className="flex items-start gap-3 text-right">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">{feature}</span>
                </li>
              ))}
            </ul>

            <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition-colors font-bold">
              اشترك الآن
            </button>
          </div>
        ))}
      </div>

      {/* Additional Info */}
      <div className="mt-12 text-center">
        <p className="text-gray-400">
          جميع الخطط تشمل ضمان استرداد المال لمدة 30 يوماً
        </p>
      </div>
    </div>
  );
};

export default Pricing;
