import { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [isSending, setIsSending] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);

    // محاكاة إرسال الرسالة
    setTimeout(() => {
      setIsSending(false);
      alert('تم إرسال رسالتك بنجاح. سنتواصل معك قريباً');
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 1500);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto" dir="rtl">
      <div className="mb-12 text-center">
        <h1 className="text-5xl font-bold mb-4">تواصل معنا</h1>
        <p className="text-xl text-gray-400">
          نحن هنا للإجابة على استفساراتك ومساعدتك
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Contact Info */}
        <div className="space-y-6">
          <div className="bg-dark-card border border-dark-border rounded-lg p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div className="text-right">
                <h3 className="text-lg font-bold mb-2">البريد الإلكتروني</h3>
                <p className="text-gray-400">support@lawai.sa</p>
              </div>
            </div>
          </div>

          <div className="bg-dark-card border border-dark-border rounded-lg p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="text-right">
                <h3 className="text-lg font-bold mb-2">الهاتف</h3>
                <p className="text-gray-400" dir="ltr">+966 50 123 4567</p>
              </div>
            </div>
          </div>

          <div className="bg-dark-card border border-dark-border rounded-lg p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div className="text-right">
                <h3 className="text-lg font-bold mb-2">العنوان</h3>
                <p className="text-gray-400">
                  الرياض، المملكة العربية السعودية
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-dark-card border border-dark-border rounded-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2 text-right">الاسم</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                placeholder="أدخل اسمك"
                dir="rtl"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2 text-right">البريد الإلكتروني</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                placeholder="example@email.com"
                dir="ltr"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2 text-right">الموضوع</label>
              <input
                type="text"
                required
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                placeholder="موضوع الرسالة"
                dir="rtl"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2 text-right">الرسالة</label>
              <textarea
                required
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 resize-none"
                rows={6}
                placeholder="اكتب رسالتك هنا..."
                dir="rtl"
              />
            </div>

            <button
              type="submit"
              disabled={isSending}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white py-3 rounded-lg transition-colors font-bold flex items-center justify-center gap-2"
            >
              <Send className="w-5 h-5" />
              <span>{isSending ? 'جاري الإرسال...' : 'إرسال الرسالة'}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
